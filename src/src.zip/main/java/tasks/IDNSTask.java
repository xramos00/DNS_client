package tasks;

public interface IDNSTask {



}
