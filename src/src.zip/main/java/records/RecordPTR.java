package records;

public class RecordPTR extends RecordCNAME {

	public RecordPTR(byte[] rawMessage, int lenght, int startIndex) {
		super(rawMessage, lenght, startIndex);
	}

}
