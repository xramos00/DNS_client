package enums;

public enum IP_PROTOCOL {
	IPv4, IPv6;
}
