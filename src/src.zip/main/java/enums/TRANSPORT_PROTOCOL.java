package enums;

public enum TRANSPORT_PROTOCOL {
	TCP, UDP
}
