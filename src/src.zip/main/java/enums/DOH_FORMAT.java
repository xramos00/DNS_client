package enums;

public enum DOH_FORMAT {
	JSON_API, WIRE;
}
