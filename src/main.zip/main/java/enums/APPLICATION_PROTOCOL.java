package enums;

public enum APPLICATION_PROTOCOL {
	DNS, MDNS, LLMR, DOH;
}
